package com.sample.model;

public class ProcessEligibilityWorkflow {
	private String paymentStatusCode;
	private String nectworkflow;
	public String getPaymentStatusCode() {
		return paymentStatusCode;
	}
	public void setPaymentStatusCode(String paymentStatusCode) {
		this.paymentStatusCode = paymentStatusCode;
	}
	public String getNectworkflow() {
		return nectworkflow;
	}
	public void setNectworkflow(String nectworkflow) {
		this.nectworkflow = nectworkflow;
	}
}
