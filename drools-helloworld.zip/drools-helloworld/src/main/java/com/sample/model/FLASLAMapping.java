package com.sample.model;

public class FLASLAMapping {
	private String FLA;
	private String SLA;
	private int BenefitAmount;
	private String ValidationResult;

	public String getSLA() {
		return SLA;
	}

	public void setSLA(String sLA) {
		SLA = sLA;
	}

	public String getFLA() {
		return FLA;
	}

	public void setFLA(String fLA) {
		FLA = fLA;
	}

	public int getBenefitAmount() {
		return BenefitAmount;
	}

	public void setBenefitAmount(int benefitAmount) {
		BenefitAmount = benefitAmount;
	}

	public String getValidationResult() {
		return ValidationResult;
	}

	public void setValidationResult(String validationResult) {
		ValidationResult = validationResult;
	}

}
