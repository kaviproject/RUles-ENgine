package com.sample.main;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import org.drools.compiler.compiler.DroolsParserException;
import org.drools.compiler.compiler.PackageBuilder;
import org.drools.core.RuleBase;
import org.drools.core.RuleBaseFactory;
import org.drools.core.WorkingMemory;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.sample.model.FLASLAMapping;

public class FLASLAMappingTest {
	//Main Method
	public static void main(String[] args) throws DroolsParserException, IOException, ParseException {
		FLASLAMappingTest fLASLAMappingTest = new FLASLAMappingTest();
		fLASLAMappingTest.parseSDXData();
	}

	JSONArray outFlaSlaArray = new JSONArray();

	public void parseSDXData() throws IOException, ParseException, DroolsParserException {
		String inputdataFile = "C:\\Users\\ParupatK\\Desktop\\sampledata.json";
		JSONParser jsonParser = new JSONParser();
		FileReader reader1 = new FileReader(inputdataFile);

		// Read JSON file
		Object obj = jsonParser.parse(reader1);
		JSONArray flaslaList = (JSONArray) obj;
		System.out.println(flaslaList);
		executeDrools(flaslaList);
	}

	@SuppressWarnings("unchecked")
	public void executeDrools(JSONArray flaslaList) throws DroolsParserException, IOException, ParseException {
		//Calling rules 
		PackageBuilder packageBuilder = new PackageBuilder();
		String ruleFile = "/com/rule/FLASLAMappingRules.drl";
		InputStream resourceAsStream = getClass().getResourceAsStream(ruleFile);
		Reader reader = new InputStreamReader(resourceAsStream);
		packageBuilder.addPackageFromDrl(reader);
		org.drools.core.rule.Package rulesPackage = packageBuilder.getPackage();
		RuleBase ruleBase = RuleBaseFactory.newRuleBase();
		ruleBase.addPackage(rulesPackage);
		WorkingMemory workingMemory = ruleBase.newStatefulSession();

		for (int i = 0; i < flaslaList.size(); i++) {
			JSONObject out = (JSONObject) flaslaList.get(i);
			FLASLAMapping fLASLAMapping = new FLASLAMapping();
			fLASLAMapping.setFLA(out.get("FLA").toString());
			fLASLAMapping.setSLA(out.get("SLA").toString());
			workingMemory.insert(fLASLAMapping);
			workingMemory.fireAllRules();


			System.out.println("Current FLA is " + fLASLAMapping.getFLA() + " Current SLA is " + fLASLAMapping.getSLA()
					+ " BenefitAmount is " + fLASLAMapping.getBenefitAmount()+" Result "+fLASLAMapping.getValidationResult());
			JSONObject outFlaSlaList = new JSONObject();
			outFlaSlaList.put("CurrentSLA", fLASLAMapping.getSLA());
			outFlaSlaList.put("BenefitAmount", fLASLAMapping.getBenefitAmount());
			outFlaSlaList.put("currentFLA", fLASLAMapping.getFLA());
			outFlaSlaList.put("validationMessage", fLASLAMapping.getValidationResult());
			outFlaSlaArray.add(outFlaSlaList);
		}
		//Writing in to the JSON File
		FileWriter file = new FileWriter("C:\\Users\\parupatK\\Desktop\\outputSDXFile.json");
		file.write(outFlaSlaArray.toJSONString());
		file.flush();
	}

}
